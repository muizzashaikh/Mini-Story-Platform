# Inkwell — Mini Story Platform

A lightweight writing and publishing platform. Write stories, publish them, and let others read, like, and comment.

---

## Stack

| Layer    | Tech |
|----------|------|
| Backend  | Node.js · Express · better-sqlite3 · bcryptjs · jsonwebtoken |
| Frontend | React 18 · React Router v6 · Vite · Axios |
| Database | SQLite (file: `backend/inkwell.db`, auto-created on first run) |

---

## Quick start

### 1. Backend

```bash
cd backend
cp .env.example .env          # edit JWT_SECRET before deploying
npm install
npm start                     # runs on http://localhost:4000
```

For development with auto-reload:
```bash
npm run dev
```

### 2. Frontend

```bash
cd frontend
npm install
npm run dev                   # runs on http://localhost:5173
```

Vite proxies `/api` → `http://localhost:4000` automatically.

---

## API reference

### Auth
| Method | Path | Body | Notes |
|--------|------|------|-------|
| POST | `/api/auth/register` | `{ name, email, password }` | Returns JWT + user |
| POST | `/api/auth/login`    | `{ email, password }`       | Returns JWT + user |

### Stories
| Method | Path | Auth | Notes |
|--------|------|------|-------|
| GET    | `/api/stories`         | optional | Published only, trending sort |
| GET    | `/api/stories/mine`    | required | All user's own stories |
| GET    | `/api/stories/:id`     | optional | Drafts → author only |
| POST   | `/api/stories`         | required | `{ title, content, status }` |
| PATCH  | `/api/stories/:id`     | required | Partial update |
| DELETE | `/api/stories/:id`     | required | Author only |
| POST   | `/api/stories/:id/like` | required | Toggle like/unlike |

### Comments
| Method | Path | Auth | Notes |
|--------|------|------|-------|
| GET    | `/api/stories/:id/comments` | optional | Ordered oldest→newest |
| POST   | `/api/stories/:id/comments` | required | `{ text }` |
| DELETE | `/api/stories/:storyId/comments/:commentId` | required | Author only |

---

## Design decisions

### 1. Trending algorithm
Score = `likes × 0.8^(ageDays) + 2 / (ageDays + 1)`

Likes are weighted with exponential decay (~3-day half-life). A recency bonus `2/(ageDays+1)` floats fresh stories above older zero-like peers. Computed in JS after a lightweight SQL SELECT; for scale, materialise the score column and update it on every like event plus a nightly cron job.

### 2. Preventing double-likes
The `story_likes` table has a composite `PRIMARY KEY (story_id, user_id)`. A duplicate INSERT raises a SQLite UNIQUE constraint error at the database level, independent of application logic. The app checks membership first for a clean API response, but the constraint is the authoritative guard — no race condition can create a double-like.

### 3. Drafts never appear publicly
The public listing query is `WHERE status = 'published'` — drafts are excluded at the SQL level, never fetched and filtered in application code. The single-story endpoint (`GET /stories/:id`) returns 404 if `status = 'draft'` and the requester is not the author, so drafts cannot be read by URL-guessing either.

### Explicit malformed-input case handled
**Malformed email address on registration/login** (e.g. `user@` or `notanemail`) is validated against `/^[^\s@]+@[^\s@]+\.[^\s@]+$/` before any password hashing or database query. Returns HTTP 400 `{ "error": "Enter a valid email address." }`. Documented in `backend/middleware/validate.js`.
