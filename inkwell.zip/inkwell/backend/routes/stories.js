const express = require('express');
const { v4: uuidv4 } = require('../utils/uuid');
const db = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const { validateStory } = require('../middleware/validate');

const router = express.Router();

/**
 * Trending score formula:
 *   score = likes * 0.8^(ageDays) + 2 / (ageDays + 1)
 *
 * Likes are weighted with exponential decay (~3-day half-life).
 * A recency bonus (2/(ageDays+1)) floats fresh stories above zero-like peers.
 * Computed in JS after a lightweight SQL fetch; suitable for datasets up to ~100k stories.
 * For scale, materialise the score column and update on every like + a nightly cron.
 */
function trendScore(story) {
  const ageDays = (Date.now() - story.created_at) / (1000 * 60 * 60 * 24);
  return story.likes * Math.pow(0.8, ageDays) + 2 / (ageDays + 1);
}

// GET /api/stories — list published stories sorted by trending score
router.get('/', optionalAuth, (req, res) => {
  // Drafts are excluded at the query level, never leaked to caller
  const stories = db.prepare(`
    SELECT s.*, u.name AS author_name
    FROM stories s
    JOIN users u ON u.id = s.author_id
    WHERE s.status = 'published'
  `).all();

  const userId = req.user?.id;
  const likedStoryIds = userId
    ? new Set(
        db.prepare('SELECT story_id FROM story_likes WHERE user_id = ?')
          .all(userId)
          .map(r => r.story_id)
      )
    : new Set();

  const result = stories
    .map(s => ({ ...s, liked: likedStoryIds.has(s.id), trend_score: trendScore(s) }))
    .sort((a, b) => b.trend_score - a.trend_score)
    .map(({ trend_score, ...rest }) => rest);  // strip internal field

  return res.json(result);
});

// GET /api/stories/mine — current user's stories (drafts + published)
router.get('/mine', requireAuth, (req, res) => {
  const stories = db.prepare(`
    SELECT s.*, u.name AS author_name
    FROM stories s
    JOIN users u ON u.id = s.author_id
    WHERE s.author_id = ?
    ORDER BY s.updated_at DESC
  `).all(req.user.id);
  return res.json(stories);
});

// GET /api/stories/:id
router.get('/:id', optionalAuth, (req, res) => {
  const story = db.prepare(`
    SELECT s.*, u.name AS author_name
    FROM stories s
    JOIN users u ON u.id = s.author_id
    WHERE s.id = ?
  `).get(req.params.id);

  if (!story) return res.status(404).json({ error: 'Story not found.' });

  // Drafts are only visible to their author — enforced in query response
  if (story.status === 'draft' && story.author_id !== req.user?.id) {
    return res.status(404).json({ error: 'Story not found.' });
  }

  const liked = req.user
    ? !!db.prepare('SELECT 1 FROM story_likes WHERE story_id = ? AND user_id = ?')
        .get(req.params.id, req.user.id)
    : false;

  return res.json({ ...story, liked });
});

// POST /api/stories
router.post('/', requireAuth, (req, res) => {
  const { title, content, status = 'draft' } = req.body || {};
  const err = validateStory({ title, content });
  if (err) return res.status(400).json({ error: err });
  if (!['draft', 'published'].includes(status)) {
    return res.status(400).json({ error: 'Status must be draft or published.' });
  }

  const id = uuidv4();
  const now = Date.now();
  db.prepare(`
    INSERT INTO stories (id, title, content, author_id, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(id, title.trim(), content.trim(), req.user.id, status, now, now);

  const story = db.prepare('SELECT * FROM stories WHERE id = ?').get(id);
  return res.status(201).json(story);
});

// PATCH /api/stories/:id
router.patch('/:id', requireAuth, (req, res) => {
  const story = db.prepare('SELECT * FROM stories WHERE id = ?').get(req.params.id);
  if (!story) return res.status(404).json({ error: 'Story not found.' });
  if (story.author_id !== req.user.id) return res.status(403).json({ error: 'Forbidden.' });

  const title   = req.body.title   !== undefined ? req.body.title   : story.title;
  const content = req.body.content !== undefined ? req.body.content : story.content;
  const status  = req.body.status  !== undefined ? req.body.status  : story.status;

  const err = validateStory({ title, content });
  if (err) return res.status(400).json({ error: err });
  if (!['draft', 'published'].includes(status)) {
    return res.status(400).json({ error: 'Status must be draft or published.' });
  }

  db.prepare(`
    UPDATE stories SET title = ?, content = ?, status = ?, updated_at = ? WHERE id = ?
  `).run(title.trim(), content.trim(), status, Date.now(), story.id);

  return res.json(db.prepare('SELECT * FROM stories WHERE id = ?').get(story.id));
});

// DELETE /api/stories/:id
router.delete('/:id', requireAuth, (req, res) => {
  const story = db.prepare('SELECT * FROM stories WHERE id = ?').get(req.params.id);
  if (!story) return res.status(404).json({ error: 'Story not found.' });
  if (story.author_id !== req.user.id) return res.status(403).json({ error: 'Forbidden.' });
  db.prepare('DELETE FROM stories WHERE id = ?').run(story.id);
  return res.json({ success: true });
});

// POST /api/stories/:id/like — toggle like
router.post('/:id/like', requireAuth, (req, res) => {
  const story = db.prepare("SELECT * FROM stories WHERE id = ? AND status = 'published'").get(req.params.id);
  if (!story) return res.status(404).json({ error: 'Story not found.' });

  const existing = db.prepare(
    'SELECT 1 FROM story_likes WHERE story_id = ? AND user_id = ?'
  ).get(story.id, req.user.id);

  /**
   * Double-like prevention:
   * The story_likes table has a PRIMARY KEY (story_id, user_id) — attempting
   * to INSERT a duplicate row raises a UNIQUE constraint error at the DB level,
   * independent of application logic. We check first here for a clean response,
   * but the constraint is the authoritative guard.
   */
  const toggleLike = db.transaction(() => {
    if (existing) {
      db.prepare('DELETE FROM story_likes WHERE story_id = ? AND user_id = ?')
        .run(story.id, req.user.id);
      db.prepare('UPDATE stories SET likes = likes - 1 WHERE id = ?').run(story.id);
      return false;
    } else {
      db.prepare('INSERT INTO story_likes (story_id, user_id) VALUES (?, ?)').run(story.id, req.user.id);
      db.prepare('UPDATE stories SET likes = likes + 1 WHERE id = ?').run(story.id);
      return true;
    }
  });

  const liked = toggleLike();
  const updated = db.prepare('SELECT likes FROM stories WHERE id = ?').get(story.id);
  return res.json({ liked, likes: updated.likes });
});

module.exports = router;
