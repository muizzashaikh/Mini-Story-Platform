const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('../utils/uuid');
const db = require('../db');
const { validateRegister, validateLogin } = require('../middleware/validate');
const { JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body || {};
  const err = validateRegister({ name, email, password });
  if (err) return res.status(400).json({ error: err });

  const normEmail = email.trim().toLowerCase();

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normEmail);
  if (existing) {
    return res.status(409).json({ error: 'An account with that email already exists.' });
  }

  const hash = await bcrypt.hash(password, 10);
  const id = uuidv4();

  db.prepare('INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)')
    .run(id, name.trim(), normEmail, hash);

  const token = jwt.sign({ id, name: name.trim(), email: normEmail }, JWT_SECRET, { expiresIn: '7d' });
  return res.status(201).json({ token, user: { id, name: name.trim(), email: normEmail } });
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  const err = validateLogin({ email, password });
  if (err) return res.status(400).json({ error: err });

  const normEmail = email.trim().toLowerCase();
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(normEmail);

  if (!user) return res.status(401).json({ error: 'Incorrect email or password.' });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ error: 'Incorrect email or password.' });

  const token = jwt.sign(
    { id: user.id, name: user.name, email: user.email },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
  return res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

module.exports = router;
