const express = require('express');
const { v4: uuidv4 } = require('../utils/uuid');
const db = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const { validateComment } = require('../middleware/validate');

const router = express.Router({ mergeParams: true });

// GET /api/stories/:storyId/comments
router.get('/', optionalAuth, (req, res) => {
  const story = db.prepare('SELECT id, status, author_id FROM stories WHERE id = ?').get(req.params.storyId);
  if (!story) return res.status(404).json({ error: 'Story not found.' });
  if (story.status === 'draft' && story.author_id !== req.user?.id) {
    return res.status(404).json({ error: 'Story not found.' });
  }

  const comments = db.prepare(`
    SELECT c.*, u.name AS author_name
    FROM comments c
    JOIN users u ON u.id = c.user_id
    WHERE c.story_id = ?
    ORDER BY c.created_at ASC
  `).all(req.params.storyId);

  return res.json(comments);
});

// POST /api/stories/:storyId/comments
router.post('/', requireAuth, (req, res) => {
  const story = db.prepare("SELECT id, status FROM stories WHERE id = ? AND status = 'published'").get(req.params.storyId);
  if (!story) return res.status(404).json({ error: 'Story not found or not published.' });

  const { text } = req.body || {};
  const err = validateComment({ text });
  if (err) return res.status(400).json({ error: err });

  const id = uuidv4();
  db.prepare('INSERT INTO comments (id, story_id, user_id, text) VALUES (?, ?, ?, ?)')
    .run(id, story.id, req.user.id, text.trim());

  const comment = db.prepare(`
    SELECT c.*, u.name AS author_name FROM comments c
    JOIN users u ON u.id = c.user_id WHERE c.id = ?
  `).get(id);

  return res.status(201).json(comment);
});

// DELETE /api/stories/:storyId/comments/:commentId
router.delete('/:commentId', requireAuth, (req, res) => {
  const comment = db.prepare('SELECT * FROM comments WHERE id = ? AND story_id = ?')
    .get(req.params.commentId, req.params.storyId);
  if (!comment) return res.status(404).json({ error: 'Comment not found.' });
  if (comment.user_id !== req.user.id) return res.status(403).json({ error: 'Forbidden.' });
  db.prepare('DELETE FROM comments WHERE id = ?').run(comment.id);
  return res.json({ success: true });
});

module.exports = router;
