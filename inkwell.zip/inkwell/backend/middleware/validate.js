const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * Validates a user registration payload.
 * Returns an error string or null.
 *
 * Explicit malformed-input case documented here:
 *   A malformed email address (e.g. "user@" or "notanemail") is caught by
 *   EMAIL_RE before any DB query. Returns HTTP 400 with a clear message.
 */
function validateRegister({ name, email, password }) {
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    return 'Name must be at least 2 characters.';
  }
  if (!email || typeof email !== 'string' || !EMAIL_RE.test(email.trim())) {
    return 'Enter a valid email address.';
  }
  if (!password || typeof password !== 'string' || password.length < 6) {
    return 'Password must be at least 6 characters.';
  }
  return null;
}

function validateLogin({ email, password }) {
  if (!email || typeof email !== 'string' || !EMAIL_RE.test(email.trim())) {
    return 'Enter a valid email address.';
  }
  if (!password || typeof password !== 'string') {
    return 'Password is required.';
  }
  return null;
}

function validateStory({ title, content }) {
  if (!title || typeof title !== 'string' || title.trim().length === 0) {
    return 'Story title is required.';
  }
  if (title.trim().length > 200) {
    return 'Title must be 200 characters or fewer.';
  }
  if (!content || typeof content !== 'string' || content.trim().length === 0) {
    return 'Story content cannot be empty.';
  }
  return null;
}

function validateComment({ text }) {
  if (!text || typeof text !== 'string' || text.trim().length === 0) {
    return 'Comment text is required.';
  }
  if (text.trim().length > 2000) {
    return 'Comment must be 2000 characters or fewer.';
  }
  return null;
}

module.exports = { validateRegister, validateLogin, validateStory, validateComment };
