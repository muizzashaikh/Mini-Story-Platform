import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Nav() {
  const { user, logout } = useAuth();
  const nav = useNavigate();

  function handleLogout() {
    logout();
    nav('/');
  }

  return (
    <nav className="topnav">
      <span className="logo" onClick={() => nav('/')}>
        inkwell<span>.</span>
      </span>
      <div className="nav-right">
        {user ? (
          <>
            <button className="btn btn-ghost btn-sm" onClick={() => nav('/my-stories')}>
              My stories
            </button>
            <button className="btn btn-primary btn-sm" onClick={() => nav('/write')}>
              <i className="ti ti-pencil" aria-hidden="true" />
              Write
            </button>
            <button className="btn btn-ghost btn-sm" onClick={handleLogout}>
              Sign out
            </button>
          </>
        ) : (
          <button className="btn btn-sm" onClick={() => nav('/auth')}>
            Sign in
          </button>
        )}
      </div>
    </nav>
  );
}
