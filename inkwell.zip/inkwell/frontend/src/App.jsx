import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import ListingPage  from './pages/ListingPage';
import AuthPage     from './pages/AuthPage';
import WritePage    from './pages/WritePage';
import ReaderPage   from './pages/ReaderPage';
import MyStoriesPage from './pages/MyStoriesPage';
import './index.css';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            <Route path="/"               element={<ListingPage />} />
            <Route path="/auth"           element={<AuthPage />} />
            <Route path="/write"          element={<WritePage />} />
            <Route path="/write/:id"      element={<WritePage />} />
            <Route path="/story/:id"      element={<ReaderPage />} />
            <Route path="/my-stories"     element={<MyStoriesPage />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
