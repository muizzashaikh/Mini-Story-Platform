import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Nav from '../components/Nav';

export default function AuthPage() {
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { login, register } = useAuth();
  const toast = useToast();
  const nav = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'login') {
        await login(email, password);
        toast('Welcome back!');
      } else {
        await register(name, email, password);
        toast('Account created. Welcome!');
      }
      nav('/');
    } catch (err) {
      setError(err.error || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  }

  function switchMode() {
    setMode(m => m === 'login' ? 'register' : 'login');
    setError('');
  }

  return (
    <div className="container">
      <Nav />
      <div style={{ maxWidth: 400, margin: '2rem auto' }}>
        <div className="card">
          <h2 style={{ fontSize: 22, fontWeight: 500, marginBottom: '1.5rem' }}>
            {mode === 'login' ? 'Welcome back' : 'Create account'}
          </h2>
          <form onSubmit={handleSubmit}>
            {mode === 'register' && (
              <div className="form-group">
                <label>Name</label>
                <input
                  type="text" value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Your name" autoFocus
                />
              </div>
            )}
            <div className="form-group">
              <label>Email</label>
              <input
                type="text" value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                type="password" value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••"
              />
            </div>
            {error && <p className="field-error" style={{ marginBottom: 12 }}>{error}</p>}
            <button
              type="submit" className="btn btn-primary" disabled={loading}
              style={{ width: '100%', padding: '10px', fontSize: 15, justifyContent: 'center' }}
            >
              {loading ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}
            </button>
          </form>
          <p style={{ marginTop: '1rem', fontSize: 14, textAlign: 'center', color: 'var(--text-secondary)' }}>
            {mode === 'login' ? 'No account? ' : 'Already have one? '}
            <button
              onClick={switchMode}
              style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', textDecoration: 'underline', fontSize: 14 }}
            >
              {mode === 'login' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
