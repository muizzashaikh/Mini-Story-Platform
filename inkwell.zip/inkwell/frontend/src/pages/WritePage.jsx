import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Nav from '../components/Nav';

export default function WritePage() {
  const { id } = useParams();          // present when editing
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [status, setStatus] = useState('draft');
  const [loading, setLoading] = useState(!!id);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const { user } = useAuth();
  const toast = useToast();
  const nav = useNavigate();

  // Redirect unauthenticated users
  useEffect(() => {
    if (!user) nav('/auth');
  }, [user]);

  // Load existing story for editing
  useEffect(() => {
    if (!id) return;
    api.get(`/stories/${id}`)
      .then(r => {
        if (r.data.author_id !== user?.id) { toast('Not your story.'); nav('/'); return; }
        setTitle(r.data.title);
        setContent(r.data.content);
        setStatus(r.data.status);
      })
      .catch(() => { toast('Story not found.'); nav('/'); })
      .finally(() => setLoading(false));
  }, [id]);

  async function save(publish) {
    setError('');
    const newStatus = publish ? 'published' : 'draft';
    setSaving(true);
    try {
      if (id) {
        await api.patch(`/stories/${id}`, { title, content, status: newStatus });
        toast(publish ? 'Story published' : 'Draft saved');
      } else {
        const { data } = await api.post('/stories', { title, content, status: newStatus });
        toast(publish ? 'Story published' : 'Draft saved');
        nav(`/write/${data.id}`, { replace: true });
      }
      if (publish) nav('/my-stories');
    } catch (err) {
      setError(err.error || 'Could not save story.');
    } finally {
      setSaving(false);
    }
  }

  const wordCount = content.trim().split(/\s+/).filter(Boolean).length;

  if (loading) return <div className="container"><Nav /><div className="spinner" /></div>;

  return (
    <div className="container">
      <Nav />
      <button className="btn btn-ghost btn-sm" style={{ paddingLeft: 0, marginBottom: '1rem' }} onClick={() => nav('/my-stories')}>
        <i className="ti ti-arrow-left" aria-hidden="true" /> My stories
      </button>

      <div className="card" style={{ padding: '1.75rem 2rem' }}>
        <input
          className="editor-title"
          type="text"
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Story title…"
        />
        <textarea
          className="editor-body"
          value={content}
          onChange={e => setContent(e.target.value)}
          placeholder="Start writing your story…"
        />
        {error && <p className="field-error" style={{ marginTop: 8 }}>{error}</p>}
        <div className="editor-toolbar">
          <span className="word-count">{wordCount} {wordCount === 1 ? 'word' : 'words'}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-sm" onClick={() => save(false)} disabled={saving}>
              <i className="ti ti-device-floppy" aria-hidden="true" />
              {saving ? 'Saving…' : 'Save draft'}
            </button>
            <button className="btn btn-primary btn-sm" onClick={() => save(true)} disabled={saving}>
              <i className="ti ti-send" aria-hidden="true" />
              Publish
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
