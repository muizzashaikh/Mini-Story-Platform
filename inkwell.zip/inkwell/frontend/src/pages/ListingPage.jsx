import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Nav from '../components/Nav';

function timeAgo(ts) {
  const d = (Date.now() - ts) / 1000;
  if (d < 60) return 'just now';
  if (d < 3600) return Math.floor(d / 60) + 'm ago';
  if (d < 86400) return Math.floor(d / 3600) + 'h ago';
  return Math.floor(d / 86400) + 'd ago';
}

function initials(name = '') {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

export default function ListingPage() {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const toast = useToast();
  const nav = useNavigate();

  useEffect(() => {
    api.get('/stories')
      .then(r => setStories(r.data))
      .catch(() => toast('Failed to load stories.'))
      .finally(() => setLoading(false));
  }, []);

  async function toggleLike(e, story) {
    e.stopPropagation();
    if (!user) { toast('Sign in to like stories'); nav('/auth'); return; }
    try {
      const { data } = await api.post(`/stories/${story.id}/like`);
      setStories(prev => prev.map(s => s.id === story.id ? { ...s, likes: data.likes, liked: data.liked } : s));
    } catch {
      toast('Could not update like.');
    }
  }

  return (
    <div className="container">
      <Nav />
      <div className="section-header">
        <h2>Trending stories</h2>
        <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{stories.length} published</span>
      </div>

      {loading && <div className="spinner" />}

      {!loading && stories.length === 0 && (
        <div className="empty">
          <i className="ti ti-book-off" aria-hidden="true" />
          No stories yet. Be the first to write one.
        </div>
      )}

      {stories.map(story => (
        <div className="story-card" key={story.id} onClick={() => nav(`/story/${story.id}`)}>
          <div className="story-meta">
            <div className="avatar avatar-sm">{initials(story.author_name)}</div>
            <span>{story.author_name}</span>
            <span>·</span>
            <span>{timeAgo(story.created_at)}</span>
          </div>
          <div className="story-title">{story.title}</div>
          <div className="story-excerpt">{story.content}</div>
          <div className="story-footer">
            <button
              className={`like-btn${story.liked ? ' liked' : ''}`}
              onClick={e => toggleLike(e, story)}
              aria-label={story.liked ? 'Unlike' : 'Like'}
            >
              <i className="ti ti-heart" style={{ fontSize: 15 }} aria-hidden="true" />
              {story.likes}
            </button>
            <span>
              <i className="ti ti-message" style={{ fontSize: 14, marginRight: 4 }} aria-hidden="true" />
              Read
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
