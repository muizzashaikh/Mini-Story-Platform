import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Nav from '../components/Nav';

function timeAgo(ts) {
  const d = (Date.now() - ts) / 1000;
  if (d < 60) return 'just now';
  if (d < 3600) return Math.floor(d / 60) + 'm ago';
  if (d < 86400) return Math.floor(d / 3600) + 'h ago';
  return Math.floor(d / 86400) + 'd ago';
}

export default function MyStoriesPage() {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const toast = useToast();
  const nav = useNavigate();

  useEffect(() => {
    if (!user) { nav('/auth'); return; }
    api.get('/stories/mine')
      .then(r => setStories(r.data))
      .catch(() => toast('Failed to load stories.'))
      .finally(() => setLoading(false));
  }, []);

  async function deleteStory(story) {
    if (!confirm(`Delete "${story.title || 'Untitled'}"?`)) return;
    try {
      await api.delete(`/stories/${story.id}`);
      setStories(s => s.filter(x => x.id !== story.id));
      toast('Story deleted.');
    } catch { toast('Could not delete story.'); }
  }

  return (
    <div className="container">
      <Nav />
      <div className="section-header">
        <h2>My stories</h2>
        <button className="btn btn-primary btn-sm" onClick={() => nav('/write')}>
          <i className="ti ti-plus" aria-hidden="true" /> New story
        </button>
      </div>

      {loading && <div className="spinner" />}

      {!loading && stories.length === 0 && (
        <div className="empty">
          <i className="ti ti-pencil-off" aria-hidden="true" />
          You haven't written anything yet.
        </div>
      )}

      {!loading && stories.length > 0 && (
        <div className="card" style={{ padding: '0 1.5rem' }}>
          {stories.map(story => (
            <div className="story-row" key={story.id}>
              <div className="story-row-info">
                <div className="story-row-title">{story.title || 'Untitled'}</div>
                <div className="story-row-meta">
                  {timeAgo(story.updated_at)} ·{' '}
                  {story.status === 'published' ? `${story.likes} ${story.likes === 1 ? 'like' : 'likes'}` : 'draft'}
                </div>
              </div>
              <div className="story-row-actions">
                <span className={`tag tag-${story.status === 'published' ? 'pub' : 'draft'}`}>
                  {story.status}
                </span>
                {story.status === 'published' && (
                  <button className="btn btn-ghost btn-sm" onClick={() => nav(`/story/${story.id}`)} title="Read">
                    <i className="ti ti-eye" aria-hidden="true" />
                  </button>
                )}
                <button className="btn btn-ghost btn-sm" onClick={() => nav(`/write/${story.id}`)} title="Edit">
                  <i className="ti ti-edit" aria-hidden="true" />
                </button>
                <button className="btn btn-ghost btn-sm btn-danger" onClick={() => deleteStory(story)} title="Delete">
                  <i className="ti ti-trash" aria-hidden="true" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
