import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Nav from '../components/Nav';

function timeAgo(ts) {
  const d = (Date.now() - ts) / 1000;
  if (d < 60) return 'just now';
  if (d < 3600) return Math.floor(d / 60) + 'm ago';
  if (d < 86400) return Math.floor(d / 3600) + 'h ago';
  return Math.floor(d / 86400) + 'd ago';
}

function initials(name = '') {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

export default function ReaderPage() {
  const { id } = useParams();
  const [story, setStory] = useState(null);
  const [comments, setComments] = useState([]);
  const [commentText, setCommentText] = useState('');
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  const { user } = useAuth();
  const toast = useToast();
  const nav = useNavigate();

  useEffect(() => {
    Promise.all([api.get(`/stories/${id}`), api.get(`/stories/${id}/comments`)])
      .then(([s, c]) => { setStory(s.data); setComments(c.data); })
      .catch(() => { toast('Story not found.'); nav('/'); })
      .finally(() => setLoading(false));
  }, [id]);

  async function toggleLike() {
    if (!user) { toast('Sign in to like stories'); nav('/auth'); return; }
    try {
      const { data } = await api.post(`/stories/${id}/like`);
      setStory(s => ({ ...s, likes: data.likes, liked: data.liked }));
    } catch { toast('Could not update like.'); }
  }

  async function submitComment(e) {
    e.preventDefault();
    if (!user) { nav('/auth'); return; }
    if (!commentText.trim()) return;
    setPosting(true);
    try {
      const { data } = await api.post(`/stories/${id}/comments`, { text: commentText });
      setComments(c => [...c, data]);
      setCommentText('');
    } catch (err) {
      toast(err.error || 'Could not post comment.');
    } finally { setPosting(false); }
  }

  async function deleteStory() {
    if (!confirm('Delete this story permanently?')) return;
    try {
      await api.delete(`/stories/${id}`);
      toast('Story deleted.');
      nav('/');
    } catch { toast('Could not delete story.'); }
  }

  if (loading) return <div className="container"><Nav /><div className="spinner" /></div>;
  if (!story) return null;

  const isOwner = user?.id === story.author_id;

  return (
    <div className="container">
      <Nav />
      <button className="btn btn-ghost btn-sm" style={{ paddingLeft: 0, marginBottom: '1.5rem' }} onClick={() => nav('/')}>
        <i className="ti ti-arrow-left" aria-hidden="true" /> Back
      </button>

      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: 30, fontWeight: 500, lineHeight: 1.25, marginBottom: 12 }}>
          {story.title}
        </h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14, color: 'var(--text-secondary)', flexWrap: 'wrap' }}>
          <div className="avatar">{initials(story.author_name)}</div>
          <span>{story.author_name}</span>
          <span style={{ color: 'var(--text-muted)' }}>·</span>
          <span style={{ color: 'var(--text-muted)' }}>{timeAgo(story.created_at)}</span>
          {isOwner && (
            <>
              <button className="btn btn-ghost btn-sm" onClick={() => nav(`/write/${id}`)}>
                <i className="ti ti-edit" aria-hidden="true" /> Edit
              </button>
              <button className="btn btn-ghost btn-sm btn-danger" onClick={deleteStory}>
                <i className="ti ti-trash" aria-hidden="true" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="reader-content">{story.content}</div>
      <hr className="reader-divider" />

      {/* Like */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: '2rem' }}>
        <button className={`like-btn${story.liked ? ' liked' : ''}`} onClick={toggleLike} style={{ fontSize: 15 }}>
          <i className="ti ti-heart" style={{ fontSize: 20 }} aria-hidden="true" />
          {story.likes} {story.likes === 1 ? 'like' : 'likes'}
        </button>
      </div>

      {/* Comments */}
      <div>
        <h3 style={{ fontSize: 16, fontWeight: 500, marginBottom: '1rem' }}>
          Comments ({comments.length})
        </h3>

        {comments.map(c => (
          <div className="comment" key={c.id}>
            <div className="comment-author">{c.author_name}</div>
            <div className="comment-body">{c.text}</div>
            <div className="comment-time">{timeAgo(c.created_at)}</div>
          </div>
        ))}

        {comments.length === 0 && (
          <p style={{ fontSize: 14, color: 'var(--text-muted)', padding: '1rem 0' }}>No comments yet.</p>
        )}

        {user ? (
          <form onSubmit={submitComment} className="comment-form">
            <input
              value={commentText}
              onChange={e => setCommentText(e.target.value)}
              placeholder="Add a comment…"
              autoComplete="off"
            />
            <button type="submit" className="btn btn-primary btn-sm" disabled={posting}>
              {posting ? '…' : 'Post'}
            </button>
          </form>
        ) : (
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: '1rem' }}>
            <button
              onClick={() => nav('/auth')}
              style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', textDecoration: 'underline', fontSize: 13 }}
            >Sign in</button> to leave a comment.
          </p>
        )}
      </div>
    </div>
  );
}
